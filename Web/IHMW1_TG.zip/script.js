// Fonction qui renvoie l'option sélectionnée de l'élément select
function getSelectedOption(sel) {
  var opt;
  for ( var i = 0, len = sel.options.length; i < len; i++ ) {
    opt = sel.options[i];
    if ( opt.selected === true ) {
      break;
    }
  }
  return opt;
}

// Script qui s'exécute quand on appuie sur le bouton Envoyer
document.forms['formulaire'].addEventListener("submit", function(e){
  e.preventDefault();//évènement revient par défaut --> permet de placer les valeurs renseignés dans le formulaire.
  
  // Changement du nom sur la carte
  var nom_pokemon = document.getElementById('nom_pokemon').value;
  if (nom_pokemon!=""){
    document.getElementById('carte_nom').textContent = nom_pokemon};
  
    // Changement du nom sur l'attaque 1
  var nom = document.getElementById('nom').value;
  if (nom!=""){
    document.getElementById('carte_attaque1_nom').textContent = nom};
	
	// Changement du nom sur l'attaque 2
  var nom2 = document.getElementById('nom2').value;
  if (nom2!=""){
    document.getElementById('carte_attaque2_nom').textContent = nom2};
	
  // Changement du nombre de points de vie sur la carte
  var pv = document.getElementById('pv');
  var sel = getSelectedOption(pv);
  document.getElementById('carte_pv').textContent = sel.textContent;
  
  // Changement de la photo sur la carte
  const reader = new FileReader();
  reader.onload = function(){
    const img = new Image();
    img.src = reader.result;
    document.getElementById('carte_photo2').src = img.src;
  };
  reader.readAsDataURL(photo.files[0]);
  
  
})

document.getElementById('type_combat').addEventListener('click', function(e){
  e.preventDefault();
  var type = document.getElementById('carte_type').getElementsByTagName('img')[0];
  type.src = 'img/energie_combat.png';
  var carte_fond = document.getElementById('carte_fond');
  carte_fond.style.backgroundColor = '#cf6e42';
})

document.getElementById('type_dragon').addEventListener('click', function(e){
  e.preventDefault();
  var type = document.getElementById('carte_type').getElementsByTagName('img')[0];
  type.src = 'img/energie_dragon.png';
  var carte_fond = document.getElementById('carte_fond');
  carte_fond.style.backgroundColor = '#cf6e42';
})