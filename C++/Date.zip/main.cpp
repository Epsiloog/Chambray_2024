#include <iostream>
#include "date.h"

using namespace std;

int main()
{
    cout << "construction" << endl;
    Date d0;
    cout << d0 << endl;

    Date* d1 = new Date(22,5,2023);
    cout << *d1 << endl;

    Date d2(*d1);
    cout << d2 << endl;
    d2=d0;
    cout << d2 << endl;

    cout << "compare" << endl;
    if ( *d1<d2 )
        cout << *d1 << " avant " << d2 << endl;
    else
        cout << *d1 << " apres " << d2 << endl;

    if ( *d1==d2 )
        cout << *d1 << " egal " << d2 << endl;
    else
        cout << *d1 << " non egal " << d2 << endl;
    if ( d2==d2 )
        cout << d2 << " egal " << d2 << endl;
    else
        cout << d2 << " non egal " << d2 << endl;

//    cout << d0.bissextile() << endl;

    cout << "incremente" << endl;
    for (auto i=0; i<7; ++i) // +1 semaine
        d1->incremente();
    cout << *d1 << endl;
    for (auto i=0; i<7; ++i) // +1 semaine, changement de mois
        d1->incremente();
    cout << *d1 << endl;
    for (auto i=0; i<30; ++i) // +1 mois (juin)
        d1->incremente();
    cout << *d1 << endl;
    for (auto i=0; i<365; ++i) // +1 an
        d1->incremente();
    cout << *d1 << endl;

    cout << "bissextile" << endl;
    Date d3(28,2,2023); // non bissextile
    cout << d3 << endl;
    for (auto i=0; i<3; ++i) {
        d3.incremente();
        cout << d3 << endl;
    }
    d3=Date(28,2,2024); // bissextile
    cout << d3 << endl;
    for (auto i=0; i<3; ++i) {
        ++d3;
        cout << d3 << endl;
    }

    cout << "operator++" << endl;
    cout << d3 << endl;
    cout << ++d3 << endl; // incremente puis affiche
    cout << d3++ << endl; // affiche puis incremente
    cout << d3 << endl;

    delete d1;
    return 0;
}
