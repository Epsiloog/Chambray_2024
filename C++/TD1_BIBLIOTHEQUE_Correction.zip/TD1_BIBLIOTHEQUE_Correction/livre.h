#ifndef LIVRE_H
#define LIVRE_H

#include<string>
#include<iostream>

class Livre
{
private:
    std::string titre;
    int nbPages;
    int emprunte;
public:
    Livre(const std::string &titre="", int nbPages=0, int emprunte=false);
    ~Livre();

    const std::string &getTitre() const;
    void setTitre(const std::string &newTitre);
    int getNbPages() const;
    void setNbPages(int newNbPages);
    int getEmprunte() const;
    void setEmprunte(int newEmprunte);

    friend std::ostream& operator<<(std::ostream& os, const Livre &l);
};

#endif // LIVRE_H
