#include <iostream>
#include "etudiant.h"
#include "livre.h"
#include "bibliotheque.h"

using namespace std;

int main()
{
    Etudiant e("p0123456789");
    cout << e.getAge() << endl;
    cout << e << endl;
    e.setNom("Bjarne Stroustrup");
    e.setNaissance(1950);
    cout << e << endl;

    Livre l("C++",256);
    cout << l.getTitre() << endl;
    cout << l << endl;

    Bibliotheque b;
    b.addLivre("C++",256,true);
    b.addLivre("Java",112);
    cout << b << endl;

    for (unsigned int i=0; i<100; ++i) {
        if  (! b.addLivre("C++",256,true))
                cerr << "Plus de place !" << endl;
    }
    cout << b << endl;

    return 0;
}
