#include "livre.h"

using namespace std;

Livre::Livre(const std::string &newTitre, int newNbPages, int newEmprunte)
    : titre(newTitre), nbPages(newNbPages), emprunte(newEmprunte)
{
    cout << "[+Livre]" << endl;
}

Livre::~Livre() {
    cout << "[-Livre]" << endl;

}

const std::string &Livre::getTitre() const
{
    return titre;
}

void Livre::setTitre(const std::string &newTitre)
{
    titre = newTitre;
}

int Livre::getNbPages() const
{
    return nbPages;
}

void Livre::setNbPages(int newNbPages)
{
    nbPages = newNbPages;
}

int Livre::getEmprunte() const
{
    return emprunte;
}

void Livre::setEmprunte(int newEmprunte)
{
    emprunte = newEmprunte;
}

std::ostream& operator<<(std::ostream& os, const Livre &l) {
    cout << l.getTitre() << " " << l.getNbPages();
    if (l.getEmprunte())
        cout << " " << "emprunte";
    else
        cout << " " << "disponible";
    return os;
}
