#ifndef BIBLIOTHEQUE_H
#define BIBLIOTHEQUE_H

#include <string>
#include <iostream>
#include "livre.h"
#include "etudiant.h"

class Bibliotheque
{
private:
    unsigned int nbLivres=0;
    Livre *livres[100];
    unsigned int nbAdherent=0;
    Etudiant *adherents[100];
public:
    Bibliotheque();
    ~Bibliotheque();

    bool addLivre(const std::string &titre, int nbPages=0, int emprunte=false);

    friend std::ostream& operator<<(std::ostream& os, const Bibliotheque &b);
    unsigned int getNbLivres() const;
    unsigned int getNbAdherent() const;
};

#endif // BIBLIOTHEQUE_H
