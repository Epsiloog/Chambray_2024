#ifndef ETUDIANT_H
#define ETUDIANT_H

#include<iostream>
#include<string>

class Etudiant
{
private:
    std::string numero;
    std::string nom;
    int naissance;
public:
    // constructeur
    Etudiant(const std::string &numero=0, const std::string &newNom="Anonymous", int newNaissance=2005);

    // accesseurs et mutateurs

    // methodes
    int getAge() const;

    const std::string &getNumero() const;
    void setNumero(const std::string &newNumero);
    const std::string &getNom() const;
    void setNom(const std::string &newNom);
    int getNaissance() const;
    void setNaissance(int newNaissance);

    friend std::ostream& operator<<(std::ostream& os, const Etudiant &e);
};

#endif // ETUDIANT_H
