#include "bibliotheque.h"

using namespace std;

Bibliotheque::Bibliotheque()
{
    cout << "[+Bibliotheque]" << endl;
}

Bibliotheque::~Bibliotheque()
{
    cout << "[-Bibliotheque]" << endl;
    for (unsigned int i=0; i<nbLivres; ++i) {
        delete livres[i];
    }
}

using namespace std;

unsigned int Bibliotheque::getNbLivres() const
{
    return nbLivres;
}

unsigned int Bibliotheque::getNbAdherent() const
{
    return nbAdherent;
}

bool Bibliotheque::addLivre(const std::string &titre, int nbPages, int emprunte) {
    if (nbLivres<100) {
        livres[nbLivres]=new Livre(titre,nbPages,emprunte);
        ++nbLivres;
        return true;
    }
    return false;
}

std::ostream& operator<<(std::ostream& os, const Bibliotheque &b) {
    cout << b.nbLivres << endl;
    for (unsigned int i=0; i<b.getNbLivres(); ++i) {
        cout << "\t" << i << " : " << *(b.livres[i]) << endl;
    }
    return os;
}
