#include <ctime>
#include "etudiant.h"

using namespace std;

Etudiant::Etudiant(const std::string & newNumero, const std::string &newNom, int newNaissance)
    : numero(newNumero), nom(newNom), naissance(newNaissance)
{
}

const std::string &Etudiant::getNumero() const
{
    return numero;
}

void Etudiant::setNumero(const std::string &newNumero)
{
    numero = newNumero;
}

const std::string &Etudiant::getNom() const
{
    return nom;
}

void Etudiant::setNom(const std::string &newNom)
{
    nom = newNom;
}

int Etudiant::getNaissance() const
{
    return naissance;
}

void Etudiant::setNaissance(int newNaissance)
{
    naissance = newNaissance;
}

int Etudiant::getAge() const {
    std::time_t t = time(nullptr);
    std::tm *const pTInfo = std::localtime(&t);
    auto annee = 1900 + pTInfo->tm_year;

    return (annee-naissance);
}

std::ostream& operator<<(std::ostream& os, const Etudiant &e) {
    cout << e.getNumero() << " " << e.getNom() << " " << e.getAge() << " ";
    return os;
}
