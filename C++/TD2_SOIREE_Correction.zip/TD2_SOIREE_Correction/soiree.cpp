#include "soiree.h"
using namespace std;

float Soiree::getRecette() const{
    float r=0.f;
    for (auto p:participant) {
        r += p->getTarif(tarif); // le polymorphisme en action
    }
    return r;
}

void Soiree::addParticipant(Participant *p) {
    participant.push_back(p); // ajout en fin de liste
}

std::ostream& operator<<(std::ostream& o, const Soiree& s) {
    o << "Soiree : le tarif est " << s.tarif << " pour une recette de " << s.getRecette() << endl;
    o << "Il y avait " << s.participant.size() << " participants." << endl;
    return o;
}
