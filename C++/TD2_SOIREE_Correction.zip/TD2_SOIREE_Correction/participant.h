#ifndef PARTICIPANT_H
#define PARTICIPANT_H

#include <iostream>

class Participant
{
public:
    Participant() {
        std::cerr << "+Participant\n";
    }
    virtual ~Participant() {
        std::cerr << "-Participant\n";
    }
    virtual float getTarif(float t) const =0;
};

class Invite : public Participant {
public:
    Invite() {
        std::cerr << "+Invite\n";
    }
    ~Invite() {
        std::cerr << "-Invite\n";
    }
    virtual float getTarif(float t) const override {
        return t;
    }

};

class Etudiant : public Participant {
public:
    Etudiant() {
        std::cerr << "+Etudiant\n";
    }
    ~Etudiant() {
        std::cerr << "-Etudiant\n";
    }
    virtual float getTarif(float t) const override {
        return t*.9f;
    }

};

class BDE : public Participant {
public:
    BDE() {
        std::cerr << "+BDE\n";
    }
    ~BDE() {
        std::cerr << "-BDE\n";
    }
    virtual float getTarif(float t) const override {
        return 2.f;
    }

};


#endif // PARTICIPANT_H
