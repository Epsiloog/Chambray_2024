#include <iostream>

#include "soiree.h"
using namespace std;

int main()
{
    Soiree s(5);
    cout << "Recette = " << s.getRecette() << endl;

//    Participant *p= new Participant(); // impossible, classe abstraite
//    s.addParticipant(p);
//    s.addParticipant(p);
//    s.addParticipant(p);
//    cout << "Recette = " << s.getRecette() << endl;

    Etudiant *p= new Etudiant(); // Etudiant herite de Participant
    s.addParticipant(p); // on peut l'ajouter plusieurs fois
    s.addParticipant(p); // ici, l'impostant est le nombre, pas les informations
    s.addParticipant(p);
    cout << "Recette = " << s.getRecette() << endl;

    Participant *e= new Etudiant(); // possible : Etudiant herite de Participant
    s.addParticipant(e);
    cout << "Recette = " << s.getRecette() << endl;

    BDE *b= new BDE();
    s.addParticipant(b);
    s.addParticipant(b);
    cout << "Recette = " << s.getRecette() << endl;

    cout << s << endl; // appel de l'operator<< sur Soiree

    delete p;
    delete e;
    delete b;

    return 0;
}
