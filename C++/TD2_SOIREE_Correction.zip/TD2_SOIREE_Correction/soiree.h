#ifndef SOIREE_H
#define SOIREE_H

#include <iostream>
#include <list>
#include "participant.h"

class Soiree
{
private:
    float tarif;
    std::list<Participant*> participant;
public:
    Soiree(float t=5.f) : tarif(t) {
       std::cerr << "+Soiree\n";
    }
    ~Soiree() {
        std::cerr << "-Soiree\n";
    }
    float getRecette() const;
    void addParticipant(Participant *p);
    friend std::ostream& operator<<(std::ostream& o, const Soiree& s);
};

#endif // SOIREE_H
