# Projet IV : niveau 1
import math

def lesAssiettes(pile1, pile2, pile3) -> bool:  #???
  """
    Fonction qui prend comme argument trois nombres entiers positifs ou nuls et renvoie un booléan, qui est égal à true si le reste de la division euclidienne de la somme de pile1, pile2, pile3 est égal à zéro.
  """
  assert type(pile1) == int, "vous devez entrer un nombre entier (entier 1)"  #cas où pile1 n'est pas un nombre entier
  assert type(pile2) == int, "vous devez entrer un nombre entier (entier 2)" #cas où le nombre n'est pas un nombre entier
  assert type(pile3) == int, "vous devez entrer un nombre entier (entier 3)"  #cas où le nombre n'est pas un nombre entier
  
  assert pile1>=0, "vous devez entrer un nombre positif ou nul (entier 1)"  #cas où pile1 n'est pas supérieur ou égal à zéro
  assert pile2>=0, "vous devez entrer un nombre positif ou nul (entier 2)"  #cas où pile2 n'est pas supérieur ou égal à zéro
  assert pile3>=0, "vous devez entrer un nombre positif ou nul (entier 3)"  #cas où pile3 n'est pas supérieur ou égal à zéro

  if (pile1 + pile2 + pile3) % 3 == 0:
    return True
  else:
    return False