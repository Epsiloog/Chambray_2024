package MesClasses;

public class Skis extends Materiel{
    private int longueur; //longueur des skis
    private String marque; //marque des skis

    /**
     * Constructeur
     * @param reference la référence du matériel
     * @param longueur la longueur des skis
     * @param marque la marque des skis
     */
    public Skis(String reference, int longueur, String marque) {
        super(reference);
        this.longueur = longueur;
        this.marque = marque;
    }

    /**
     * Accesseur
     * @return la longueur des skis
     */
    public int getLongueur() {
        return longueur;
    }

    /**
     * Redéfinition de la méthode d'affichage
     * @return la chaîne à afficher
     */
    @Override
    public String toString() {
         return "\nSKIS\nMARQUE: "+marque+"\nLONGUEUR: "+longueur+"\n"+super.toString();
    }

    /**
     * Redéfinition de la méthode de calcul de prix à la journée
     * @return le prix de la location pour 1 journée
     */
    @Override
    public double getPrixJournee() {
        if(this.reference.equals("Rossignol"))
            return 20;
        if(this.reference.equals("Atomic"))
            return 18;
        return 14;
    }
}
