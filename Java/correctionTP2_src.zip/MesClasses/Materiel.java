package MesClasses;

public abstract class Materiel {
    protected String reference; //référence du matériel
    protected boolean disponible; //disponibilité du matériel (true=disponible, false sinon)

    /**
     * Constructeur
     * @param reference référence du matériel
     */
    public Materiel(String reference) {
        this.reference = reference;
        this.disponible=true; //par défaut le matériel est disponible
    }

    /**
     * Accesseur à la référence
     * @return la référence
     */
    public String getReference() {
        return reference;
    }

    /**
     * Accesseur à la disponibilité
     * @return true si le matériel est disponible, false sinon
     */
    public boolean isDisponible() {
        return disponible;
    }

    /**
     * Mutateur de la disponibilité
     * @param disponible la nouvelle disponibilité
     */
    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    /**
     * Redéfinition de la méthode d'affichage
     * @return la chaîne à afficher
     */
    @Override
    public String toString() {
        String s="REF: "+reference+"\nDISPONIBLE: ";
        if(disponible)
            return s+"OUI";
        else
            return s+"NON";
    }

    /**
     * Redéfinition de equals
     * @param obj l'objet auquel this est comparé
     * @return true si les objets sont calculés égaux, false sinon
     */
    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Materiel){
            Materiel mat=(Materiel)obj;
            return this.reference.equals(mat.reference);
        }
        return false;
    }

    /**
     * Calcule le coût de location d'une journée
     * @return le prix de location pour 1 journée
     */
    public abstract double getPrixJournee();
}
