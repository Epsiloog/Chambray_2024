package MesClasses;

public class Chaussures extends Materiel{
    private int pointure; //pointure des chaussures

    /**
     * Constructeur
     * @param reference référence du matériel
     * @param pointure pointure des chaussures
     */
    public Chaussures(String reference, int pointure) {
        super(reference);
        this.pointure = pointure;
    }

    /**
     * Accesseur
     * @return la pointure des chaussures
     */
    public int getPointure() {
        return pointure;
    }

    /**
     * Redéfinition de la méthode d'affichage
     * @return la chaîne à afficher
     */
    @Override
    public String toString() {
        return "\nCHAUSSURES\nPOINTURE: "+pointure+"\n"+super.toString();
    }

    /**
     * Redéfinition de la méthode de calcul de prix à la journée
     * @return le prix de la location pour 1 journée
     */
    @Override
    public double getPrixJournee() {
        return 12;
    }
}
