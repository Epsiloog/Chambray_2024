package MesClasses;

public class Luge extends Materiel{
    private int nbPlaces; //nbre de places de la luge

    /**
     * Constructeur
     * @param reference référence du matériel
     * @param nbPlaces nombre de places de la luge
     */
    public Luge(String reference, int nbPlaces) {
        super(reference);
        this.nbPlaces = nbPlaces;
    }

    /**
     * Accesseur
     * @return le nombre de places de la luge
     */
    public int getNbPlaces() {
        return nbPlaces;
    }

    /**
     * Redéfinition de la méthode d'affichage
     * @return la chaîne à afficher
     */
    @Override
    public String toString() {
        return "\nLUGE\nNB PLACES: "+nbPlaces+"\n"+super.toString();
    }

    /**
     * Redéfinition de la méthode de calcul de prix à la journée
     * @return le prix de la location pour 1 journée
     */
    @Override
    public double getPrixJournee() {
        if(nbPlaces==1)
            return 8;
        return 12;
    }
}
