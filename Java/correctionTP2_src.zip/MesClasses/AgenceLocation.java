package MesClasses;

import MesClasses.Materiel;

import java.util.ArrayList;

public class AgenceLocation {
    private ArrayList<Materiel> matos =new ArrayList<>(); //liste des matériels de l'agence

    /**
     * Ajoute un matériel à la liste, à condition qu'il ne soit pas déjà dans la liste
     * @param m le matériel à ajouter
     * @return true si le matériel a été ajouté, false sinon
     */
    public boolean ajouterMateriel(Materiel m){
        if(!matos.contains(m)){
            matos.add(m);
            return true;
        }
        return false;
    }

    /**
     * Affiche la fiche descriptive du matériel
     * @param ref la référence du matériel
     */
    public void consulterFiche(String ref){
        for(Materiel m:matos){
            if(m.getReference().equals(ref)){
                System.out.println(m);
                return;
            }
        }
    }

    /**
     * Location de luge, si une luge avec le nombre de places requis est disponible elle est louée, sinon message d'information
     * @param nbPlaces le nombre de places de la luge
     */
    public void louerLuge(int nbPlaces){
        for(Materiel m:matos){
            if(m instanceof Luge && m.isDisponible() && ((Luge)m).getNbPlaces()==nbPlaces){
                System.out.println(m);
                System.out.println("Prix de la location: "+m.getPrixJournee());
                m.setDisponible(false);
                return;
            }
        }
        System.out.println("Aucune luge avec ce nombre de places n'est disponible");
    }

    /**
     * Location de skis+chaussures, si une paire de chaussures à la pointure voulue et une paire de skis à la taille voulue sont dispo, elles sont louées,
     * si un des matériel est manquant aucune location n'est faite et message d'information
     * @param longueur longueur des skis
     * @param pointure pointure des chaussures
     */
    public void louerSkisChaussures(int longueur, int pointure){
        Materiel[]t=new Materiel[2];
        for(Materiel m:matos){
            //on cherche une paire de skis à la bonne longueur
            if(t[0]==null && m instanceof Skis && m.isDisponible() && ((Skis)m).getLongueur()==longueur){
                t[0]=m;
            }
            //on cherche une paire de chaussure à la bonne pointure
            if(t[1]==null && m instanceof Chaussures && m.isDisponible() && ((Chaussures)m).getPointure()==pointure){
                t[1]=m;
            }
        }
        if(t[0]==null || t[1]==null){
            System.out.println("Au moins un des matériels n'est pas disponible, la location est annulée");
        }else{
            System.out.println("Location effectuée:");
            System.out.println(t[0]);
            t[0].setDisponible(false);
            System.out.println(t[1]);
            t[1].setDisponible(false);
            System.out.println("Prix de la location: "+(t[0].getPrixJournee()+t[1].getPrixJournee()));
        }
    }

    /**
     * Retour de matériel
     * @param ref la référence du matériel rendu
     */
    public void rendreMateriel(String ref){
        for(Materiel m:matos){
            if(m.getReference().equals(ref)){
                m.setDisponible(true);
                return;
            }
        }
    }

    /**
     * Calcule la somme des matériels loués actuellement
     * @return la somme des prix à la journée
     */
    public double getMoney(){
        double somme=0.0;
        for(Materiel m:matos){
            if(!m.isDisponible())
                somme+=m.getPrixJournee();
        }
        return somme;
    }

}
